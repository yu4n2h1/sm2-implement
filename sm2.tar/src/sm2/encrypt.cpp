#include "encrypt.hpp"
#include <gmpxx.h>
#include <iostream>
#include "sm2.hpp"
#include "sha256.hpp"
#include "sha256.hpp"
#include <string>

uint8_t* HextoByte(std::string input) {
    uint8_t res[input.length()/2];
    for(int i=0;i< input.length(); i+= 2) {
        res[i/2] = (int)(input.at(i) << 8) + (int)(input.at(i+1));
    }
    return res;
}


std::string encrypt(std::string M, EllipticCurvePoint& G ,EllipticCurvePoint& P ) {
    // gmp_randclass randObj(gmp_randinit_default);
    // mpz_class k = randObj.get_z_range(G.a.modulus); 
    mpz_class k = mpz_class("384F30353073AEECE7A1654330A96204D37982A3E15B2CB5",16);
    
    EllipticCurvePoint C1 = G * k;

    std::string stringC1 = C1.Out_Hex_xy();
    EllipticCurvePoint kP = P * k; 
    std::string out2 = kP.Out_Hex_xy();

    // std::string out256 = KDF(out2,152);
    std::cout << out2 << std::endl;
    mpz_class mpzC2 = mpz_class(M,16) ^ mpz_class(out2, 16);
    std::string stringC2 = mpzC2.get_str();
    std::cout << stringC2 << std::endl;
    std::string stringC3 = sha256(kP.point.first.value.get_str() + M + kP.point.second.value.get_str());
    return stringC1 + stringC2 + stringC3;
}

// std::string KDF(const std::string input, uint32_t klen) {
//     uint32_t ct = 0x1;
//     // std::string intemp = input;
//     uint32_t v = 32;
//     std::string key;
//     for(int i=1;i<=((klen%v==0)?klen/v:klen/v+1) ;i++) {
//         u_char tmp[4] = {0, 0, 0, 0};
//         tmp[0] = (u_char)ct >> 24;
//         tmp[1] = (u_char)ct >> 16;
//         tmp[2] = (u_char)ct >> 8;
//         tmp[3] = (u_char)ct;
//         key += sha256(input + std::string(tmp));
//         ct ++;
//     }
//     return key.substr(0,klen);
// }