#!/bin/bash

make > /dev/null

./bin/main
